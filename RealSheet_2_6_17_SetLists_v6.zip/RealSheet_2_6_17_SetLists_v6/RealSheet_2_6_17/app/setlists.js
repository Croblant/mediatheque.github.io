
/* RealSheet - local Set Lists */
(function () {
  'use strict';
  var STORE = 'rsSetLists_v1', activeId = null, selectedIndex = -1, searchTimer = null, searchRun = 0;
  function el(id) { return document.getElementById(id); }
  function loadLists() {
    try { var x = JSON.parse(localStorage.getItem(STORE) || '[]'); return Array.isArray(x) ? x : []; }
    catch (_) { return []; }
  }
  function saveLists(x) { localStorage.setItem(STORE, JSON.stringify(x)); safeRenderOverview(); safeRenderVirtualBooks(); }
  function safeRenderOverview(){ try { renderOverview(); } catch(err){ console.error('Set Lists overview:',err); } }
  function safeRenderVirtualBooks(){ try { renderVirtualBooks(); } catch(err){ console.error('Set Lists tunebooks:',err); } }
  function uid() { return 'sl_' + Date.now().toString(36) + Math.random().toString(36).slice(2,7); }
  function esc(s) { return String(s || '').replace(/[&<>"']/g, function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
  function currentList() { return loadLists().find(function(x){return x.id===activeId;}); }
  function ensureListShape(list) {
    if (!list || typeof list !== 'object') return null;
    if (!Array.isArray(list.entries)) list.entries = [];
    if (!list.id) list.id = uid();
    if (!list.name) list.name = 'Untitled';
    return list;
  }
  function renumber(list) { if(!Array.isArray(list.entries)) list.entries=[]; list.entries.forEach(function(e,i){ e.number=i+1; e.display=(i+1)+'. '+e.sourceTitle; }); }
  function openPanel() {
    var trigger=el('menuManageTunebooks');
    if (trigger) trigger.click();
    setTimeout(function(){
      var all=document.querySelectorAll('#sideNav .nav-page');
      all.forEach(function(p){p.style.display='none';});
      el('navSetLists').style.display='block';
      el('navSetLists').scrollTop=0;
      renderOverview(); renderVirtualBooks();
    }, 80);
  }
  function showOverview() {
    el('setListEditor').style.display='none';
    el('setListsCreateArea').style.display='flex';
    el('setListsOverview').style.display='block';
    el('setListsVirtualBooks').style.display='block';
    activeId=null; selectedIndex=-1; renderOverview();
  }
  function renderOverview() {
    var host=el('setListsOverview'); if(!host) return;
    var lists=loadLists();
    host.innerHTML='';
    if(!lists.length) { host.innerHTML='<p>No set lists yet.</p>'; return; }
    var ul=document.createElement('ul'); ul.className='setlists-list';
    lists.forEach(function(list){
      var li=document.createElement('li');
      var label=document.createElement('span'); label.className='setlists-label';
      label.textContent=list.name+' ('+(list.entries||[]).length+')';
      var edit=document.createElement('button'); edit.innerHTML='<img src="img/edit.png" alt="Edit"> Edit';
      edit.addEventListener('click',function(){openEditor(list.id);});
      var del=document.createElement('button'); del.innerHTML='<img src="img/trash.png" alt="Delete"> Delete';
      del.addEventListener('click',function(){if(confirm('Delete set list "'+list.name+'"?')) saveLists(loadLists().filter(function(x){return x.id!==list.id;}));});
      li.append(label,edit,del); ul.appendChild(li);
    });
    host.appendChild(ul);
  }
  function openEditor(id) {
    activeId=id; selectedIndex=-1;
    var list=ensureListShape(currentList());
    if(!list) { showOverview(); return false; }
    // Show the editor first; optional Tunes integration must not prevent opening it.
    var create=el('setListsCreateArea'), overview=el('setListsOverview'),
        books=el('setListsVirtualBooks'), editor=el('setListEditor');
    if(create) create.style.display='none';
    if(overview) overview.style.display='none';
    if(books) books.style.display='none';
    if(editor) editor.style.display='block';
    var name=el('setListEditName'), search=el('setListTuneSearch');
    if(name) name.value=list.name;
    if(search) search.value='';
    try { renderEntries(); } catch(err) { console.error('Set List entries render failed:',err); }
    try { populateTuneFilter(); } catch(err) { console.warn('Set List filter unavailable:',err); }
    try { renderSearch(''); } catch(err) { console.warn('Set List search unavailable:',err); }
    return !!editor;
  }
  function renderEntries() {
    var list=ensureListShape(currentList()), host=el('setListEntries'); if(!list||!host)return;
    renumber(list);
    host.innerHTML='';
    list.entries.forEach(function(entry,i){
      var row=document.createElement('div'); row.className='setlist-entry'+(i===selectedIndex?' selected':'');
      row.textContent=entry.display;
      row.addEventListener('click',function(){selectedIndex=(selectedIndex===i?-1:i);renderEntries();});
      host.appendChild(row);
    });
    host.scrollTop=0;
  }
  function updateActive(mutator) {
    var lists=loadLists(), list=lists.find(function(x){return x.id===activeId;});
    if(!list)return; mutator(list); renumber(list); localStorage.setItem(STORE,JSON.stringify(lists)); renderEntries(); renderOverview(); renderVirtualBooks();
  }
  function populateTuneFilter() {
    var source=el('tbFilter'), target=el('setListTuneFilter');
    if(!source || !target) return;
    var previous=target.value || source.value || 'all';
    target.innerHTML='';
    Array.prototype.forEach.call(source.options,function(option){
      var copy=document.createElement('option');
      copy.value=option.value; copy.textContent=option.textContent;
      copy.disabled=option.disabled;
      target.appendChild(copy);
    });
    target.value=Array.prototype.some.call(target.options,function(o){return o.value===previous;}) ? previous : (source.value || 'all');
  }
  function tuneCandidates() {
    var box=el('tuneList'); if(!box)return [];
    // Tunes renders tune rows as identified elements (not necessarily anchors).
    var nodes=Array.prototype.slice.call(box.querySelectorAll('[id]'));
    var seen=Object.create(null);
    return nodes.map(function(node){
      var raw=(node.textContent||'').replace(/\s+/g,' ').trim();
      var title=raw.split(' — ')[0].split(' - ')[0].trim();
      var id=String(node.id||'');
      if(!id || !title || seen[id] || node.children.length>3) return null;
      seen[id]=true; return {id:id,title:title,label:raw};
    }).filter(Boolean);
  }
  function renderSearch(query) {
    var host=el('setListSearchResults'); if(!host)return;
    var run=++searchRun, mainSearch=el('tuneSearch'), filter=el('tbFilter'), localFilter=el('setListTuneFilter');
    if(!mainSearch || !filter)return;
    host.innerHTML='';
    var previousQuery=mainSearch.value, previousFilter=filter.value;
    var desiredFilter=localFilter ? localFilter.value : previousFilter;
    // Let the application's own Tunes filter/search build the authoritative result list.
    mainSearch.value=query || '';
    filter.value=desiredFilter;
    mainSearch.dispatchEvent(new Event('input',{bubbles:true}));
    mainSearch.dispatchEvent(new Event('keyup',{bubbles:true}));
    filter.dispatchEvent(new Event('change',{bubbles:true}));
    setTimeout(function(){
      if(run!==searchRun)return;
      var matches=tuneCandidates();
      // Capture matches before restoring the user's normal Tunes view.
      mainSearch.value=previousQuery;
      filter.value=previousFilter;
      mainSearch.dispatchEvent(new Event('input',{bubbles:true}));
      mainSearch.dispatchEvent(new Event('keyup',{bubbles:true}));
      filter.dispatchEvent(new Event('change',{bubbles:true}));
      host.innerHTML='';
      if(!query) matches=matches.slice(0,4);
      matches.forEach(function(t){
        var b=document.createElement('button'); b.type='button'; b.className='setlist-result'; b.textContent=t.label;
        b.addEventListener('click',function(){
          updateActive(function(list){
            if(!list.entries.some(function(e){return String(e.sourceId)===String(t.id);}))
              list.entries.push({sourceId:t.id,sourceTitle:t.title});
          });
          el('setListTuneSearch').value=''; renderSearch('');
        });
        host.appendChild(b);
      });
      if(!matches.length) host.innerHTML='<div class="setlist-no-results">No matching tunes</div>';
    },300);
  }
  function renderVirtualBooks() {
    var host=el('setListsVirtualBooks');
    var ul=document.querySelector('#navManageTunes ul.tuneBookList');
    if(!ul)return;
    // Set lists are represented inline as ordinary local tunebook rows.
    ul.querySelectorAll('li[data-setlist-id]').forEach(function(li){li.remove();});
    loadLists().forEach(function(list){
      var li=document.createElement('li'); li.dataset.setlistId=list.id;
      var img=document.createElement('img'); img.src='img/book-local.png'; img.className='bookCover';
      var label=document.createElement('span'); label.className='tuneBookListText'; label.textContent=list.name+' ('+list.entries.length+')';
      var del=document.createElement('img'); del.src='img/trash100.png'; del.className='tuneBookListButton2'; del.alt='Delete'; del.title='Delete set list';
      del.addEventListener('click',function(ev){
        ev.stopPropagation();
        if(confirm('Delete set list "'+list.name+'"?')) saveLists(loadLists().filter(function(x){return x.id!==list.id;}));
      });
      li.append(img,label,del); li.addEventListener('click',function(){openSetListTunes(list);});
      ul.appendChild(li);
    });
    if(host) host.innerHTML='';
  }
  function openSetListTunes(list) {
    // Show the set-list's source tunes in the existing tune browser.
    var main=el('menuTunes'); if(main) main.click();
    setTimeout(function(){
      var box=el('tuneSearch'); if(box){box.value='';box.dispatchEvent(new Event('input',{bubbles:true}));}
      var container=el('tuneList')||document;
      var links=Array.prototype.slice.call(container.querySelectorAll('a[id]'));
      var wanted=list.entries.map(function(e){return String(e.sourceId);});
      var byId={}; links.forEach(function(a){byId[String(a.id)]=a;a.style.display='none';});
      // Reorder visible entries exactly as numbered in the set list.
      wanted.forEach(function(id){if(byId[id]){byId[id].style.display='';container.appendChild(byId[id]);}});
      var count=el('nrOfTunes'); if(count) count.textContent=' ('+wanted.length+')';
    },150);
  }
  var style=document.createElement('style');
  style.textContent=`
    .setlists-create{display:flex;align-items:center;gap:10px;width:100%;}
    .setlists-create input{flex:1;min-width:0;height:42px;box-sizing:border-box;margin:0;line-height:20px;}
    .setlists-create button{display:inline-flex;align-items:center;justify-content:center;align-self:stretch;height:42px;min-height:42px;box-sizing:border-box;margin:0;padding:0 12px;line-height:20px;white-space:nowrap;vertical-align:top;}
    .setlists-create button img{width:22px;height:22px;object-fit:contain;display:block;}
    .setlist-search-controls{display:flex;align-items:center;gap:7px;width:100%;}
    .setlist-search-controls input{flex:1;min-width:0;}
    .setlist-search-controls select{max-width:45%;min-width:105px;}
    .setlist-search-results{max-height:calc(4 * 42px);overflow-y:auto;overscroll-behavior:contain;}
    .setlist-result{display:block;width:100%;text-align:left;min-height:40px;}
  `;
  document.head.appendChild(style);
  document.addEventListener('DOMContentLoaded',function(){
    var menu=el('menuEditSetLists');
    if(menu) menu.addEventListener('click',function(e){e.preventDefault();openPanel();});
    if(el('setListsHamburger')) el('setListsHamburger').addEventListener('click',function(){
      el('navSetLists').style.display='none';
      el('navManageTunes').style.display='block';
      renderVirtualBooks();
    });
    var createButton=el('setListCreate');
    if(createButton) createButton.addEventListener('click',function(){
      var nameInput=el('setListNewName');
      var name=nameInput ? nameInput.value.trim() : '';
      if(!name){ if(nameInput) nameInput.focus(); return; }
      var list={id:uid(),name:name,entries:[]};
      try {
        var lists=loadLists();
        lists.push(list);
        localStorage.setItem(STORE,JSON.stringify(lists));
        if(nameInput) nameInput.value='';
      } catch(err) {
        console.error('Unable to save Set List:',err);
        alert('The set list could not be saved. Check that local storage is available.');
        return;
      }
      // Opening is independent from saving and from the Tunes search subsystem.
      try {
        var opened=openEditor(list.id);
        if(!opened) throw new Error('Set List editor container is missing from the page');
      } catch(err) {
        console.error('Unable to open Set List editor:',err);
        // Keep the saved list visible and recoverable instead of blanking the panel.
        var ed=el('setListEditor'), cr=el('setListsCreateArea'), ov=el('setListsOverview');
        if(ed) ed.style.display='none';
        if(cr) cr.style.display='flex';
        if(ov) ov.style.display='block';
        safeRenderOverview();
        alert('The set list was saved, but the editor could not be opened. Please reopen it from the list.');
      }
      safeRenderOverview(); safeRenderVirtualBooks();
    });
    if(el('setListEditName')) el('setListEditName').addEventListener('input',function(){updateActive(function(list){list.name=el('setListEditName').value.trim()||'Untitled';});});
    if(el('setListTuneSearch')) el('setListTuneSearch').addEventListener('input',function(){clearTimeout(searchTimer);var q=this.value;searchTimer=setTimeout(function(){try{renderSearch(q);}catch(err){console.error(err);}},180);});
    if(el('setListTuneFilter')) el('setListTuneFilter').addEventListener('change',function(){try{renderSearch(el('setListTuneSearch').value);}catch(err){console.error(err);}});
    el('setListUp').addEventListener('click',function(){updateActive(function(list){if(selectedIndex>0){var x=list.entries.splice(selectedIndex,1)[0];list.entries.splice(selectedIndex-1,0,x);selectedIndex--;}});});
    el('setListDown').addEventListener('click',function(){updateActive(function(list){if(selectedIndex>=0&&selectedIndex<list.entries.length-1){var x=list.entries.splice(selectedIndex,1)[0];list.entries.splice(selectedIndex+1,0,x);selectedIndex++;}});});
    el('setListRemove').addEventListener('click',function(){updateActive(function(list){if(selectedIndex>=0){list.entries.splice(selectedIndex,1);selectedIndex=-1;}});});
    el('setListDone').addEventListener('click',showOverview);
    renderOverview(); renderVirtualBooks();
  });
})();
