---
name: realsheet-abc-audio
description: >-
  Use this skill when working on ABC music notation parsing, transposition,
  chord symbol formatting, key accidentals, tuplets, gracenotes, SVG rendering,
  print layout, or ABCJS audio playback and auto-scroll in RealSheet.
---

# RealSheet ABC & Audio Engine

Guide d'intervention sur la chaîne de rendu ABC, la mise en page SVG/impression et le lecteur audio `ABCJS.synth`.

## Règles critiques

1. **Ne jamais écraser `app/lib/abc.js`** par un bundle `abcjs` standard sans conserver les deux patchs documentés dans [abc-pipeline.md](./references/abc-pipeline.md) (nuplets multi-chiffres et calcul de durée des `gracenotes` / `acciaccatura`).
2. **Conserver l'ordre exact du pipeline de transformation ABC** (`app/main.js` lignes 2902–2944) :
   - Nettoyage des retours ligne et guillemets typographiques.
   - Injection conditionnelle du tempo par défaut (`Q:3/8=120` ou `Q:1/4=120`) + classe `body.rs-hide-tempo`.
   - Calcul des demi-tons de transposition (`steps` + `steps2` instrument) et correction `"Cb`→`"B`, `"Fb`→`"E`.
   - `window.rsFlattenNestedTuplets(r)` **avant** `ABCJS.strTranspose`.
   - Remplacements des symboles d'accords jazz (`m7b5`→`ø7`, `maj7`→`Δ7`, `-7`→`m7`, etc.).
   - `window.rsApplyAllKeyAccidentals(s)` **après** transposition (si `rsAllKeyAccidentals === '1'`).
3. **Audio & Mobile (Chrome Android)** :
   - Ne pas partager manuellement un `AudioContext` global avec `ABCJS.synth.CreateSynth()` : laisser `abcjs` gérer son contexte interne pour éviter la désynchronisation avec `ABCJS.TimingCallbacks`.
   - Attendre `await synth.start()` avant de lancer `window.__rsPlaybackTiming.start()`.
   - Sur redimensionnement/rotation à code ABC identique (`rsSameTune`), conserver `window.__rsPlaybackSynth` et rattacher uniquement `TimingCallbacks` au nouveau rendu SVG.
4. **Rendu SVG & Impression** :
   - Consulter [abc-pipeline.md](./references/abc-pipeline.md) avant de modifier `#paper svg`, `.abcjs-chord`, `.abcjs-repeat`, ou les variables CSS `--sheet-hw` / `--notes-h` dans `@media print`.
