# Pipeline ABC, Rendu SVG et Audio — RealSheet

## 1. Transformations du texte ABC (`app/main.js`, lignes 2902–2944)

1. **Normalisation** (lignes 2902–2905) : unifie `\r\n` en `\n` et convertit les guillemets/apostrophes typographiques (`“”‘’`) en guillemets ASCII `"` / `'`.
2. **Tempo par défaut** (lignes 2906–2919) :
   - Si aucun champ `Q:` n'est présent, ajoute `Q:3/8=120` pour les mesures composées en `/8` (`6/8`, `9/8`, `12/8`) ou `Q:1/4=120` sinon, juste après `K:` (ou en tête).
   - Ajoute la classe `rs-hide-tempo` sur `document.body` pour que `player.css` masque `.abcjs-tempo` à l'affichage tout en alimentant le synthétiseur.
3. **Transposition & enharmonies** (lignes 2920–2933) :
   - Combine le décalage utilisateur (`#steps`) et le décalage instrument (`#steps2` / `RealSheetLastInstrument`).
   - Remplace `"Cb` par `"B` et `"Fb` par `"E`.
4. **Aplatissement des nuplets imbriqués** (lignes 127–203, appelé ligne 2934) :
   - `window.rsFlattenNestedTuplets(r)` transforme les nuplets imbriqués (ex. `(17:8:35 ... (3EFG`) en tronçons successifs `(p:q:r` de facteur combiné pour éviter les durées `NaN` dans `abcjs` (qui feraient échouer tout le playback).
5. **Transposition ABCJS & symboles d'accords** (lignes 2935–2942) :
   - `ABCJS.parseOnly` + `ABCJS.strTranspose` + helpers internes (`xe`, `xo`, `$N`).
   - Normalisation typographique des accords : `m7b5`→`ø7`, `mmaj7`, `maj7`→`Δ7`, `maj9`→`Δ9`, `-7`→`m7`, `-6`→`m6`, `-9`→`m9`, `-11`, `°7"`→`dim7"`, `°"`.
6. **Mode `All #/b`** (lignes 5–122, appelé ligne 2943) :
   - Si `localStorage.getItem('rsAllKeyAccidentals') === '1'`, `window.rsApplyAllKeyAccidentals(s)` explicite les dièses/bémols de l'armure (`K:` et `[K:...]`) devant les notes concernées dans chaque mesure.

---

## 2. Rendu SVG en deux passes (lignes 2945–3015)

1. **Passe 1 (mesure hors écran)** : `ABCJS.renderAbc("*", s, { staffwidth: 720, ... })` mesure la largeur réelle (`viewBox.baseVal.width`) et le ratio largeur/hauteur.
2. **Passe 2 (rendu final)** : `ABCJS.renderAbc(..., s, { staffwidth: R, oneSvgPerLine: true, jazzchords: true, add_classes: true, ... })` génère un `<svg>` par ligne dans `#paper`.
   - **Débordement CSS** (`player.css` lignes 1220–1223) : `#paper svg` et `#paper .abcjs-inner > div` ont `overflow: visible !important` pour ne pas rogner les accords agrandis (`1.3em`).
   - **Reprises** (lignes 3006–3015) : ajoute `.abcjs-repeat` sur les `.abcjs-annotation` correspondant à `D.C.`, `D.S.`, `Fine`, `Coda`, `To Coda`, etc., décalées via `transform: translateY(-.6em)` dans `player.css`.
   - **Impression une page** (`player.css` lignes 1493–1557) : utilise `--sheet-hw` et `--notes-h` avec `cqw` / `cqh` pour ajuster la partition sur 1 page sans débordement.

---

## 3. Patchs internes dans `app/lib/abc.js` (`v=1001-shortbar`)

Par rapport à `app/lib/lib initiale/abc.js` (abcjs v6.7.2) :
- **Ligne 3 (parseur de nuplets)** : lit une séquence de chiffres (`e[j]>="0"&&e[j]<="9"`) après `(` au lieu d'un seul caractère, permettant `(10`, `(17:8:35`, etc.
- **Lignes 4–19 (`gracenotes` / `acciaccatura`)** :
  - Calcule des durées pondérées avec plancher (`floorSeconds = slashed ? .018 : .045`) et plafond de budget (`noteLength * (slashed ? .22 : .60)`).
  - Ligne 19 : soustrait `graceTotal` à la durée de la note principale (`T.duration = Math.max(0, T.duration - graceTotal); T.start += graceTotal`) au lieu de diviser brutalement la durée de la note par 2.

---

## 4. Moteur audio & suivi visuel (lignes 3016–3287)

- `#rsPlaybackControls` (`#rsPlaybackPlay` + `#rsPlaybackStatus`) est injecté dans `#menu`.
- Lecture : `ABCJS.synth.CreateSynth()` -> `init({ visualObj: window.__rsCurrentVisual })` -> `prime()` -> `await synth.start()` -> `window.__rsPlaybackTiming.start()`.
- Surlignage : ajoute `.abcjs-highlight` (`#1976d2`) aux éléments SVG courants de l'événement `TimingCallbacks`.
- Défilement auto (`window.__rsAutoFollow`) : fait défiler lorsque la ligne jouée entre dans les 25 % inférieurs de l'écran ou lors d'un retour en arrière (reprise), sauf si l'utilisateur a scrollé manuellement sur la ligne courante (`window.__rsAuto.handled = true`).
