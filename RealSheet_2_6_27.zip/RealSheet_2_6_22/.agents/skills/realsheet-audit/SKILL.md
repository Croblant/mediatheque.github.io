---
name: realsheet-audit
description: >-
  Use this skill whenever asked to audit, inspect, diagnose, or verify the
  health, security, PWA cache consistency, or code integrity of the RealSheet
  project.
---

# RealSheet Audit

Procédure d'audit statique, PWA/offline, sécurité et intégrité des patchs de RealSheet.

## Étapes d'audit

1. **Exécuter l'audit automatisé** depuis la racine du workspace :
   ```bash
   node .agents/skills/realsheet-audit/scripts/audit-project.mjs
   ```
   Pour traiter les avertissements comme des erreurs bloquantes :
   ```bash
   node .agents/skills/realsheet-audit/scripts/audit-project.mjs --strict
   ```
2. **Analyser les résultats** :
   - Les `[FAIL]` indiquent un défaut bloquant (ressource 404 dans `PRECACHE_URLS`, lien cassé, JSON invalide, sidecar `.json.js` désynchronisé, patch critique manquant).
   - Les `[WARN]` signalent des anomalies à évaluer (ex. image utilisée en JS absente du précache Service Worker, fichiers orphelins ou doublons de bibliothèques).
3. **Compléter avec la grille d'audit manuelle** dans [audit-checklist.md](./references/audit-checklist.md) pour couvrir :
   - Le comportement en mode `http(s)://` (Service Worker, fallback `getkey.php`, CORS) et en mode `file://` (`filemode.js`).
   - Le rendu musical ABC, la transposition, l'impression `@media print` et le playback audio sur desktop et mobile.
   - La sécurité du relais `proxy.php` / `serve.mjs` / `serve.py` et des entrées utilisateur (`escapeHtml`, URL externes).
4. **Tester l'application en local** via `node serve.mjs 8000` puis inspection sur `http://localhost:8000/app/main.html` et `http://localhost:8000/forum/forum.html`.
