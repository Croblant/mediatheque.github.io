#!/usr/bin/env node
/**
 * Audit statique et PWA automatisé pour RealSheet.
 * Usage : node .agents/skills/realsheet-audit/scripts/audit-project.mjs [--strict]
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = path.resolve(SCRIPT_DIR, '..', '..', '..', '..');
const STRICT = process.argv.includes('--strict');

const results = { pass: [], warn: [], fail: [] };

function pass(msg) { results.pass.push(msg); }
function warn(msg) { results.warn.push(msg); }
function fail(msg) { results.fail.push(msg); }

async function exists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function walkFiles(dir, baseDir = dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...(await walkFiles(full, baseDir)));
    } else {
      files.push({
        full,
        rel: path.relative(baseDir, full).replace(/\\/g, '/'),
      });
    }
  }
  return files;
}

function stripHtmlComments(html) {
  return html.replace(/<!--[\s\S]*?-->/g, '');
}

function extractLocalAssets(html) {
  const clean = stripHtmlComments(html);
  const urls = [];
  for (const match of clean.matchAll(/(?:src|href)=["']([^"']+)["']/gi)) {
    const raw = match[1].trim();
    if (!raw || raw === '#' || /^(?:https?:|mailto:|data:|javascript:)/i.test(raw)) {
      continue;
    }
    const cleanRel = raw.split(/[?#]/)[0];
    if (cleanRel) urls.push({ raw, cleanRel });
  }
  return urls;
}

function parsePrecacheUrls(swText) {
  const match = swText.match(/const\s+PRECACHE_URLS\s*=\s*\[([\s\S]*?)\];/);
  if (!match) return null;
  const urls = [];
  for (const m of match[1].matchAll(/['"]([^'"]+)['"]/g)) {
    urls.push(m[1]);
  }
  return urls;
}

function loadSidecarData(sidecarText, expectedKey) {
  const sandbox = { window: {} };
  vm.runInNewContext(sidecarText, sandbox, { timeout: 1000 });
  const files = sandbox.window.__RS_FILES__;
  if (!files || !Object.prototype.hasOwnProperty.call(files, expectedKey)) {
    return { found: false, data: null };
  }
  return { found: true, data: files[expectedKey] };
}

async function auditServiceWorker(appFiles) {
  const swPath = path.join(ROOT_DIR, 'app', 'service-worker.js');
  if (!(await exists(swPath))) {
    fail('app/service-worker.js introuvable');
    return { precacheSet: new Set() };
  }

  const swText = await fs.readFile(swPath, 'utf8');
  const cacheMatch = swText.match(/const\s+CACHE_NAME\s*=\s*['"]([^'"]+)['"]/);
  if (cacheMatch) {
    pass(`Service Worker CACHE_NAME = "${cacheMatch[1]}"`);
  } else {
    warn('Service Worker CACHE_NAME introuvable');
  }

  const precache = parsePrecacheUrls(swText);
  if (!precache) {
    fail('Impossible de lire PRECACHE_URLS dans app/service-worker.js');
    return { precacheSet: new Set() };
  }

  const precacheSet = new Set();
  let missingInApp = 0;
  for (const item of precache) {
    if (item === './' || item === '.') continue;
    const clean = item.split(/[?#]/)[0];
    precacheSet.add(clean);
    const target = path.join(ROOT_DIR, 'app', clean);
    if (!(await exists(target))) {
      fail(`PRECACHE_URLS référence un fichier inexistant : app/${clean}`);
      missingInApp++;
    }
  }
  if (missingInApp === 0) {
    pass(`PRECACHE_URLS (${precache.length} entrées) : tous les fichiers existent dans app/`);
  }

  // Vérifier les fichiers actifs dans app/ absents de PRECACHE_URLS
  const ignoredPatterns = [
    /^service-worker\.js$/,
    /^manifest\.json$/,
    /^lang\.json\.js$/,
    /^lib\/github\//,
    /^lib\/lib initiale\//,
  ];
  const uncached = [];
  for (const f of appFiles) {
    if (ignoredPatterns.some((rx) => rx.test(f.rel))) continue;
    if (!precacheSet.has(f.rel)) {
      uncached.push(f.rel);
    }
  }
  if (uncached.length > 0) {
    warn(`Fichiers dans app/ absents de PRECACHE_URLS (${uncached.length}) : ${uncached.join(', ')}`);
  } else {
    pass('Tous les fichiers actifs de app/ sont dans PRECACHE_URLS');
  }

  return { precacheSet };
}

async function auditHtmlAssets() {
  const htmlTargets = [
    { file: 'app/main.html', baseDir: path.join(ROOT_DIR, 'app') },
    { file: 'forum/forum.html', baseDir: path.join(ROOT_DIR, 'forum') },
    { file: 'main.html', baseDir: ROOT_DIR },
  ];

  const referencedFromApp = new Set();

  for (const target of htmlTargets) {
    const full = path.join(ROOT_DIR, target.file);
    if (!(await exists(full))) {
      fail(`${target.file} introuvable`);
      continue;
    }
    const html = await fs.readFile(full, 'utf8');
    const assets = extractLocalAssets(html);
    let broken = 0;
    for (const a of assets) {
      const resolved = path.resolve(target.baseDir, a.cleanRel);
      if (!(await exists(resolved))) {
        fail(`${target.file} référence un fichier manquant : ${a.raw}`);
        broken++;
      } else if (target.file === 'app/main.html') {
        const relFromApp = path.relative(path.join(ROOT_DIR, 'app'), resolved).replace(/\\/g, '/');
        if (!relFromApp.startsWith('..')) referencedFromApp.add(relFromApp);
      }
    }
    if (broken === 0) {
      pass(`${target.file} : ${assets.length} ressources locales valides`);
    }
  }

  return referencedFromApp;
}

async function auditJsonAndSidecars() {
  const manifestPath = path.join(ROOT_DIR, 'app', 'manifest.json');
  try {
    const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8'));
    pass(`app/manifest.json valide (start_url="${manifest.start_url}")`);
    if (Array.isArray(manifest.icons)) {
      for (const icon of manifest.icons) {
        if (icon.src && !(await exists(path.join(ROOT_DIR, 'app', icon.src)))) {
          fail(`app/manifest.json référence une icône manquante : ${icon.src}`);
        }
      }
    }
  } catch (err) {
    fail(`app/manifest.json invalide : ${err.message}`);
  }

  const pairs = [
    { json: 'app/lang.json', sidecar: 'app/lang.json.js', key: 'lang.json' },
    { json: 'forum/forum.json', sidecar: 'forum/forum.json.js', key: 'forum.json' },
  ];

  const tunebooksDir = path.join(ROOT_DIR, 'forum', 'tunebooks');
  if (await exists(tunebooksDir)) {
    const tbFiles = await fs.readdir(tunebooksDir);
    for (const name of tbFiles) {
      if (name.endsWith('.json')) {
        pairs.push({
          json: `forum/tunebooks/${name}`,
          sidecar: `forum/tunebooks/${name}.js`,
          key: name,
        });
      }
    }
  }

  for (const pair of pairs) {
    const jsonPath = path.join(ROOT_DIR, pair.json);
    const sidecarPath = path.join(ROOT_DIR, pair.sidecar);

    let jsonData;
    try {
      jsonData = JSON.parse(await fs.readFile(jsonPath, 'utf8'));
    } catch (err) {
      fail(`${pair.json} invalide : ${err.message}`);
      continue;
    }

    if (!(await exists(sidecarPath))) {
      fail(`Sidecar manquant pour le mode file:// : ${pair.sidecar}`);
      continue;
    }

    try {
      const sidecarText = await fs.readFile(sidecarPath, 'utf8');
      const { found, data } = loadSidecarData(sidecarText, pair.key);
      if (!found) {
        fail(`${pair.sidecar} ne définit pas window.__RS_FILES__["${pair.key}"]`);
        continue;
      }
      if (JSON.stringify(jsonData) !== JSON.stringify(data)) {
        fail(`Désynchronisation entre ${pair.json} et ${pair.sidecar}`);
      } else {
        pass(`Synchronisation OK : ${pair.json} <-> ${pair.sidecar}`);
      }
    } catch (err) {
      fail(`Erreur d'exécution de ${pair.sidecar} : ${err.message}`);
    }
  }
}

async function auditPatchesIntegrity() {
  const rsPath = path.join(ROOT_DIR, 'app', 'main.js');
  const rsText = await fs.readFile(rsPath, 'utf8');

  const rsMarkers = [
    ['window.rsApplyAllKeyAccidentals', 'Mode All #/b'],
    ['window.rsFlattenNestedTuplets', 'Aplatissement nuplets imbriqués'],
    ['rs-hide-tempo', 'Tempo par défaut masqué (.rs-hide-tempo)'],
    ['abcjs-repeat', 'Marquage annotations de reprise (.abcjs-repeat)'],
    ['rsPlaybackControls', 'Lecteur audio intégré (#rsPlaybackControls)'],
    ['window.__rsAutoFollow', 'Suivi visuel automatique en lecture'],
    ['function Wq(', 'Extraction nom de fichier proxy.php (Wq)'],
    ['window.__rsLastRenderW', 'Garde de resize vertical mobile'],
    ['function _0x30a7(', 'Décodeur _0x30a7'],
    ['function _0x3e41()', 'Table de chaînes _0x3e41'],
  ];

  let missingRs = 0;
  for (const [needle, label] of rsMarkers) {
    if (!rsText.includes(needle)) {
      fail(`Patch manquant dans app/main.js : ${label} (${needle})`);
      missingRs++;
    }
  }
  if (missingRs === 0) {
    pass(`app/main.js : tous les ${rsMarkers.length} marqueurs et patchs critiques sont présents`);
  }

  const abcPath = path.join(ROOT_DIR, 'app', 'lib', 'abc.js');
  const abcText = await fs.readFile(abcPath, 'utf8');
  const abcMarkers = [
    ['acciaccatura', 'Gestion acciaccatura dans gracenotes'],
    ['floorSeconds', 'Plancher temporel gracenotes'],
    ['graceTotal', 'Soustraction durée gracenotes sur note principale'],
    ['e[j]>="0"&&e[j]<="9"', 'Support nuplets multi-chiffres'],
    ['e.lines=e.lines.filter((function(e){return!e.staff||e.staff.length>0}))', 'Suppression des lignes sans portée (%%staffnonote, option Hide empty lines)'],
    ['rsPrevLines', 'Fusion des voies d\'accords entre voix d\'une même portée (chordLines)'],
  ];
  let missingAbc = 0;
  for (const [needle, label] of abcMarkers) {
    if (!abcText.includes(needle)) {
      fail(`Patch manquant dans app/lib/abc.js : ${label}`);
      missingAbc++;
    }
  }
  if (missingAbc === 0) {
    pass(`app/lib/abc.js : tous les ${abcMarkers.length} patchs abcjs personnalisés sont présents`);
  }

  const fmPath = path.join(ROOT_DIR, 'app', 'filemode.js');
  const fmText = await fs.readFile(fmPath, 'utf8');
  if (fmText.includes('REMOTE_GETKEY') && fmText.includes('__RS_FILES__')) {
    pass('app/filemode.js : gestion mode file:// et fallback getkey.php présents');
  } else {
    fail('app/filemode.js : structure attendue (REMOTE_GETKEY / __RS_FILES__) absente');
  }
}

async function auditUnusedAndDuplicates(appFiles, referencedFromApp, precacheSet) {
  const rsText = await fs.readFile(path.join(ROOT_DIR, 'app', 'main.js'), 'utf8');
  const cssText = await fs.readFile(path.join(ROOT_DIR, 'app', 'css', 'player.css'), 'utf8');
  const manifestText = await fs.readFile(path.join(ROOT_DIR, 'app', 'manifest.json'), 'utf8');
  const installText = await fs.readFile(path.join(ROOT_DIR, 'app', 'installmenu.js'), 'utf8');
  const combinedRefs = rsText + '\n' + cssText + '\n' + manifestText + '\n' + installText;

  // Vérifier playback.js
  if (!combinedRefs.includes('RealSheetPlayback')) {
    warn('app/playback.js définit RealSheetPlayback mais la classe n’est jamais instanciée (lecteur inline dans main.js)');
  }

  // Vérifier les images de app/img/ (en tenant compte de PRECACHE_URLS car main.js obfusque certains noms de fichiers)
  const imgFiles = appFiles.filter((f) => f.rel.startsWith('img/'));
  const unreferencedImgs = [];
  for (const img of imgFiles) {
    const fileName = path.basename(img.rel);
    if (
      !referencedFromApp.has(img.rel) &&
      !precacheSet.has(img.rel) &&
      !combinedRefs.includes(img.rel) &&
      !combinedRefs.includes(fileName)
    ) {
      unreferencedImgs.push(img.rel);
    }
  }
  if (unreferencedImgs.length > 0) {
    warn(`Images dans app/img/ ni référencées en clair ni précachées (${unreferencedImgs.length}) : ${unreferencedImgs.join(', ')}`);
  } else {
    pass('Toutes les images de app/img/ sont référencées ou précachées');
  }

  // Vérifier les dossiers de backup dans app/lib/
  for (const backupDir of ['app/lib/github', 'app/lib/lib initiale']) {
    const fullDir = path.join(ROOT_DIR, backupDir);
    if (await exists(fullDir)) {
      const files = await walkFiles(fullDir);
      let totalBytes = 0;
      for (const f of files) {
        totalBytes += (await fs.stat(f.full)).size;
      }
      warn(`Dossier de sauvegarde présent : ${backupDir}/ (${files.length} fichiers, ${(totalBytes / 1024).toFixed(0)} Ko) — non utilisé à l’exécution`);
    }
  }
}

async function main() {
  console.log(`=== Audit RealSheet (${ROOT_DIR}) ===\n`);
  const appFiles = await walkFiles(path.join(ROOT_DIR, 'app'));

  const { precacheSet } = await auditServiceWorker(appFiles);
  const referencedFromApp = await auditHtmlAssets();
  await auditJsonAndSidecars();
  await auditPatchesIntegrity();
  await auditUnusedAndDuplicates(appFiles, referencedFromApp, precacheSet);

  console.log('--- PASS ---');
  for (const m of results.pass) console.log(`  [PASS] ${m}`);

  if (results.warn.length) {
    console.log('\n--- WARN ---');
    for (const m of results.warn) console.log(`  [WARN] ${m}`);
  }

  if (results.fail.length) {
    console.log('\n--- FAIL ---');
    for (const m of results.fail) console.log(`  [FAIL] ${m}`);
  }

  console.log(`\nRésumé : ${results.pass.length} PASS, ${results.warn.length} WARN, ${results.fail.length} FAIL`);

  if (results.fail.length > 0 || (STRICT && results.warn.length > 0)) {
    process.exitCode = 1;
  }
}

main().catch((err) => {
  console.error('Erreur fatale pendant l’audit :', err);
  process.exitCode = 1;
});
