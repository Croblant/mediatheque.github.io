#!/usr/bin/env node
/**
 * Affiche ou met à jour les versions de cache-busting (?v=...) et CACHE_NAME du Service Worker.
 *
 * Usage :
 *   node .agents/skills/realsheet-tunebooks-sync/scripts/bump-version.mjs --status
 *   node .agents/skills/realsheet-tunebooks-sync/scripts/bump-version.mjs --tag 1007-fix [--sw app-cache-v62-fix] [--targets css/player.css,realsheet.js] [--app-version "RealSheet v 142.261114"] [--dry-run]
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = path.resolve(SCRIPT_DIR, '..', '..', '..', '..');

function parseArgs(argv) {
  const args = { status: false, dryRun: false, targets: ['css/player.css', 'realsheet.js'] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--status') args.status = true;
    else if (a === '--dry-run') args.dryRun = true;
    else if (a === '--tag' && argv[i + 1]) args.tag = argv[++i];
    else if (a === '--sw' && argv[i + 1]) args.sw = argv[++i];
    else if (a === '--app-version' && argv[i + 1]) args.appVersion = argv[++i];
    else if (a === '--targets' && argv[i + 1]) {
      args.targets = argv[++i].split(',').map((s) => s.trim()).filter(Boolean);
    }
  }
  return args;
}

function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function nextCacheName(current, tag) {
  const m = /^app-cache-v(\d+)(?:-.*)?$/i.exec(current);
  const nextNum = m ? Number(m[1]) + 1 : 1;
  const cleanTag = String(tag || '')
    .replace(/^\d+-/, '')
    .replace(/[^a-zA-Z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return cleanTag ? `app-cache-v${nextNum}-${cleanTag}` : `app-cache-v${nextNum}`;
}

async function showStatus() {
  const swPath = path.join(ROOT_DIR, 'app', 'service-worker.js');
  const appHtmlPath = path.join(ROOT_DIR, 'app', 'realsheet.html');
  const forumHtmlPath = path.join(ROOT_DIR, 'forum', 'forum.html');

  const swText = await fs.readFile(swPath, 'utf8');
  const appHtml = await fs.readFile(appHtmlPath, 'utf8');
  const forumHtml = await fs.readFile(forumHtmlPath, 'utf8');

  const cacheMatch = swText.match(/const\s+CACHE_NAME\s*=\s*['"]([^'"]+)['"]/);
  const verMatch = appHtml.match(/<span id="realsheetVersion">([^<]+)<\/span>/);

  console.log(`Service Worker CACHE_NAME : ${cacheMatch ? cacheMatch[1] : '(introuvable)'}`);
  console.log(`Version affichée (#realsheetVersion) : ${verMatch ? verMatch[1] : '(introuvable)'}`);

  console.log('\nVersions ?v= dans app/realsheet.html :');
  for (const m of appHtml.matchAll(/(?:src|href)=["']([^"'#]+\?v=[^"']+)["']/gi)) {
    console.log(`  - ${m[1]}`);
  }

  console.log('\nVersions ?v= dans forum/forum.html :');
  for (const m of forumHtml.matchAll(/(?:src|href)=["']([^"'#]+\?v=[^"']+)["']/gi)) {
    console.log(`  - ${m[1]}`);
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.status || (!args.tag && !args.sw && !args.appVersion)) {
    await showStatus();
    if (!args.status) {
      console.log('\nAstuce : passez --tag <nouvelle-version> pour mettre à jour ?v= et CACHE_NAME.');
    }
    return;
  }

  const swPath = path.join(ROOT_DIR, 'app', 'service-worker.js');
  const appHtmlPath = path.join(ROOT_DIR, 'app', 'realsheet.html');

  let swText = await fs.readFile(swPath, 'utf8');
  let appHtml = await fs.readFile(appHtmlPath, 'utf8');

  const cacheMatch = swText.match(/const\s+CACHE_NAME\s*=\s*['"]([^'"]+)['"]/);
  if (!cacheMatch) {
    throw new Error('Impossible de localiser CACHE_NAME dans app/service-worker.js');
  }
  const currentCache = cacheMatch[1];
  const newCache = args.sw || nextCacheName(currentCache, args.tag);

  if (newCache !== currentCache) {
    swText = swText.replace(
      /(const\s+CACHE_NAME\s*=\s*['"])([^'"]+)(['"])/,
      `$1${newCache}$3`
    );
    console.log(`[SW] CACHE_NAME : ${currentCache} -> ${newCache}`);
  }

  if (args.tag) {
    for (const target of args.targets) {
      const rx = new RegExp(`((?:src|href)=["']${escapeRegExp(target)})(?:\\?v=[^"']*)?(["'])`, 'g');
      if (!rx.test(appHtml)) {
        console.warn(`[WARN] Cible non trouvée dans app/realsheet.html : ${target}`);
        continue;
      }
      appHtml = appHtml.replace(rx, `$1?v=${args.tag}$2`);
      console.log(`[HTML] ${target} -> ${target}?v=${args.tag}`);
    }
  }

  if (args.appVersion) {
    const verRx = /(<span id="realsheetVersion">)([^<]+)(<\/span>)/;
    if (verRx.test(appHtml)) {
      appHtml = appHtml.replace(verRx, `$1${args.appVersion}$3`);
      console.log(`[HTML] #realsheetVersion -> ${args.appVersion}`);
    }
  }

  if (args.dryRun) {
    console.log('\n[--dry-run] Aucun fichier modifié.');
    return;
  }

  await fs.writeFile(swPath, swText, 'utf8');
  await fs.writeFile(appHtmlPath, appHtml, 'utf8');
  console.log('\nVersions mises à jour avec succès.');
}

main().catch((err) => {
  console.error('Erreur :', err.message);
  process.exitCode = 1;
});
