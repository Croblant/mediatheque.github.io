#!/usr/bin/env node
/**
 * Synchronise les fichiers .json de RealSheet avec leurs sidecars .json.js
 * nécessaires au mode file:// (double-clic via app/filemode.js).
 *
 * Usage :
 *   node .agents/skills/realsheet-tunebooks-sync/scripts/sync-sidecars.mjs          (génère/met à jour)
 *   node .agents/skills/realsheet-tunebooks-sync/scripts/sync-sidecars.mjs --check  (vérifie uniquement)
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = path.resolve(SCRIPT_DIR, '..', '..', '..', '..');
const CHECK_ONLY = process.argv.includes('--check');

async function exists(p) {
  try {
    await fs.access(p);
    return true;
  } catch {
    return false;
  }
}

async function collectTargets() {
  const targets = [
    {
      jsonRel: 'app/lang.json',
      sidecarRel: 'app/lang.json.js',
      key: 'lang.json',
      pretty: false,
      header: '',
    },
    {
      jsonRel: 'forum/forum.json',
      sidecarRel: 'forum/forum.json.js',
      key: 'forum.json',
      pretty: true,
      header:
        '/* Copie de forum.json pour le mode file:// (double-clic). A garder identique a forum.json.\n' +
        '   Modifiable a la main : ajoutez une entree {...} dans la liste, sans oublier la virgule entre deux entrees. */\n',
    },
  ];

  const tbDir = path.join(ROOT_DIR, 'forum', 'tunebooks');
  if (await exists(tbDir)) {
    const entries = await fs.readdir(tbDir);
    for (const name of entries.sort()) {
      if (name.endsWith('.json')) {
        targets.push({
          jsonRel: `forum/tunebooks/${name}`,
          sidecarRel: `forum/tunebooks/${name}.js`,
          key: name,
          pretty: false,
          header: '',
        });
      }
    }
  }
  return targets;
}

function readSidecar(text, key) {
  const sandbox = { window: {} };
  vm.runInNewContext(text, sandbox, { timeout: 1000 });
  const files = sandbox.window.__RS_FILES__;
  if (!files || !Object.prototype.hasOwnProperty.call(files, key)) {
    return { found: false, value: null };
  }
  return { found: true, value: files[key] };
}

async function main() {
  const targets = await collectTargets();
  let errors = 0;
  let updated = 0;

  for (const t of targets) {
    const jsonPath = path.join(ROOT_DIR, t.jsonRel);
    const sidecarPath = path.join(ROOT_DIR, t.sidecarRel);

    if (!(await exists(jsonPath))) {
      console.error(`[ERREUR] Fichier source absent : ${t.jsonRel}`);
      errors++;
      continue;
    }

    let parsed;
    try {
      parsed = JSON.parse(await fs.readFile(jsonPath, 'utf8'));
    } catch (err) {
      console.error(`[ERREUR] JSON invalide dans ${t.jsonRel} : ${err.message}`);
      errors++;
      continue;
    }

    let inSync = false;
    if (await exists(sidecarPath)) {
      try {
        const sidecarText = await fs.readFile(sidecarPath, 'utf8');
        const { found, value } = readSidecar(sidecarText, t.key);
        if (found && JSON.stringify(parsed) === JSON.stringify(value)) {
          inSync = true;
        }
      } catch (err) {
        if (CHECK_ONLY) {
          console.error(`[ERREUR] Sidecar illisible ${t.sidecarRel} : ${err.message}`);
          errors++;
          continue;
        }
      }
    }

    if (CHECK_ONLY) {
      if (inSync) {
        console.log(`[OK] ${t.jsonRel} <-> ${t.sidecarRel}`);
      } else {
        console.error(`[DESYNC] ${t.jsonRel} <-> ${t.sidecarRel}`);
        errors++;
      }
    } else if (inSync) {
      console.log(`[UNCHANGED] ${t.sidecarRel} est déjà synchronisé`);
    } else {
      const serialized = t.pretty ? JSON.stringify(parsed, null, 2) : JSON.stringify(parsed);
      const output =
        `${t.header}window.__RS_FILES__=window.__RS_FILES__||{};\n` +
        `window.__RS_FILES__[${JSON.stringify(t.key)}]=${serialized};\n`;
      await fs.writeFile(sidecarPath, output, 'utf8');
      console.log(`[UPDATED] ${t.sidecarRel} régénéré depuis ${t.jsonRel}`);
      updated++;
    }
  }

  if (CHECK_ONLY) {
    if (errors > 0) {
      console.error(`\n${errors} fichier(s) désynchronisé(s) ou invalide(s). Exécutez sans --check pour réparer.`);
      process.exitCode = 1;
    } else {
      console.log('\nTous les sidecars .json.js sont synchronisés.');
    }
  } else {
    console.log(`\nTerminé : ${updated} sidecar(s) mis à jour, ${errors} erreur(s).`);
    if (errors > 0) process.exitCode = 1;
  }
}

main().catch((err) => {
  console.error('Erreur fatale :', err);
  process.exitCode = 1;
});
