---
name: realsheet-tunebooks-sync
description: >-
  Use this skill when adding, updating, decrypting, or publishing RealSheet
  tunebooks (.abc, .abct, .json), editing forum/forum.json or app/lang.json,
  synchronizing .json.js sidecars for file:// mode, or bumping PWA cache
  versions for deployment.
---

# RealSheet Tunebooks & Sync

Procédures pour gérer le catalogue `forum/`, synchroniser les sidecars `file://` (`.json.js`), déchiffrer les tunebooks `.json` en `.abct` et incrémenter les versions de cache avant mise en ligne.

## 1. Synchroniser les sidecars `.json` ↔ `.json.js`

Après toute modification de `app/lang.json`, `forum/forum.json` ou d'un tunebook dans `forum/tunebooks/*.json` :

- **Vérifier l'état de synchronisation** (sans modifier de fichiers) :
  ```bash
  node .agents/skills/realsheet-tunebooks-sync/scripts/sync-sidecars.mjs --check
  ```
- **Régénérer les fichiers `.json.js`** :
  ```bash
  node .agents/skills/realsheet-tunebooks-sync/scripts/sync-sidecars.mjs
  ```

## 2. Ajouter ou modifier un tunebook dans `forum/forum.json`

Chaque entrée de `forum/forum.json` suit la structure :
```json
{
  "title": "Nom du tunebook",
  "description": "Description courte",
  "category": "External Tunebooks",
  "update": "",
  "contributor": "Auteur",
  "url": "https://...",
  "image": "img/book-globe.png"
}
```
- Si `update` est `""`, `forum/forum.js` interroge l'en-tête HTTP `Last-Modified` (sauf en `file://`).
- Si le tunebook est hébergé sur un domaine sans CORS, il passe par `api/proxy.php` (ou `serve.mjs` / `serve.py` en local).
- Après modification, exécuter `sync-sidecars.mjs` pour mettre à jour `forum/forum.json.js`.

## 3. Déchiffrer un tunebook `.json` en `.abct`

Pour convertir un tunebook chiffré (`1_PD.json`, `2_Jazz_Tunes.json`, etc.) en `.abct` via `realsheet.net/api/getkey.php` :
```bash
node convertir-abct.mjs forum/tunebooks/mon_tunebook.json
```
*(En environnement navigateur, `convertir-abct.html` propose la même conversion).*

## 4. Incrémenter les versions de cache avant déploiement

Avant de déployer sur `realsheettest.fwh.is` ou de générer un zip de release :
- **Afficher les versions actuelles** :
  ```bash
  node .agents/skills/realsheet-tunebooks-sync/scripts/bump-version.mjs --status
  ```
- **Incrémenter le cache Service Worker et les query strings `?v=`** :
  ```bash
  node .agents/skills/realsheet-tunebooks-sync/scripts/bump-version.mjs --tag 1007-feature-name
  ```
  *(Par défaut, met à jour `css/player.css`, `realsheet.js` dans `app/realsheet.html` et incrémente `CACHE_NAME` dans `app/service-worker.js`. Utiliser `--dry-run` pour prévisualiser).*
- **Audit final** :
  ```bash
  node .agents/skills/realsheet-audit/scripts/audit-project.mjs
  ```
