---
name: realsheet-feature-dev
description: >-
  Use this skill when designing, implementing, or modifying UI elements, menus,
  preferences, exports, or application features in RealSheet without breaking
  existing obfuscated code, PWA caching, or file:// compatibility.
---

# RealSheet Feature Development

Workflow recommandé pour ajouter ou améliorer une fonctionnalité dans RealSheet (`app/` et `forum/`).

## Étapes d'implémentation

1. **Identifier les points d'ancrage** dans [dom-and-hooks.md](./references/dom-and-hooks.md) :
   - Préférer les extensions non invasives : script inline ou module JS dédié chargé après `realsheet.js` dans `app/realsheet.html` (comme le fait `displayAllSharp` ou `installmenu.js`), ou fonction en clair `window.rs...` avant `_0x30a7` dans `app/realsheet.js`.
   - Ne jamais déplacer ni renuméroter les entrées de `_0x3e41` dans `app/realsheet.js`.
2. **Ajouter les styles dans `app/css/player.css`** :
   - Respecter les breakpoints mobiles (`max-width: 370px`, `max-height: 450px`), desktop paysage (`orientation: landscape and hover: hover and pointer: fine`), et l'impression une page (`@media print`).
   - Masquer les contrôles interactifs ajoutés à l'écran lors de l'impression (`@media print`) si nécessaire.
3. **Gérer le mode hors ligne et `file://`** :
   - Tout nouveau fichier JS, CSS, police ou image dans `app/` doit être ajouté à `PRECACHE_URLS` dans `app/service-worker.js`.
   - Si une fonctionnalité ajoute des textes `data-i18n`, mettre à jour `app/lang.json` et régénérer `app/lang.json.js`.
   - Si la fonctionnalité repose sur une nouvelle icône déjà présente (ex. `app/img/up.png`, `app/img/down.png`), vérifier qu'elle est bien listée dans `PRECACHE_URLS`.
4. **Incrémenter les versions de cache** :
   - Utiliser `node .agents/skills/realsheet-tunebooks-sync/scripts/bump-version.mjs` (ou mettre à jour `?v=...` dans `app/realsheet.html` et `CACHE_NAME` dans `app/service-worker.js`).
5. **Valider avant livraison** :
   - Lancer `node .agents/skills/realsheet-audit/scripts/audit-project.mjs`.
   - Démarrer `node serve.mjs 8000` et vérifier les modes desktop/mobile, la lecture, la transposition et l'impression.
