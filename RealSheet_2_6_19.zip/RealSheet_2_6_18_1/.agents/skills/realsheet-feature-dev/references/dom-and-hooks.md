# Référence DOM, Hooks et Stockage — RealSheet

## 1. Barre d'outils supérieure (`#menu`)
Conteneur principal : `<div id="menu" class="menu">` (`position: fixed; top: 0`).
- `#showTitlesMenu` : bouton retour vers la liste des morceaux (`Tunes`).
- `#menuHideOnNoTitle` : masqué lorsqu'aucun morceau n'est ouvert :
  - `#key2` : affichage de la tonalité courante.
  - `#steps` : sélecteur de transposition chromatique (`-12` à `+12`).
  - `#steps2` : sélecteur de transposition par instrument (`0`, `2` B♭, `9`/`-3` E♭, `7`/`-5` F, `5` G, `-12`/`-10`/`-24`/`-22` Bass).
  - `#display-dropdown` (déclenché par `#displaybutton`) :
    - `#displayStandardButton`, `#displaySmallerButton`, `#displaySmallestButton`
    - `#displayHideLyrics`, `#displayLargeChords`, `#displayAllSharp` (initialisé par script dédié dans `app/realsheet.html` lignes 41–66).
  - `#favbutton` : favoris (`img/heartxl.png` / `img/heartxlb.png`).
  - `#more-dropdown` (déclenché par `#morebutton`) :
    - `#notesButton`, `#printButton`, `#exportPdfButton`, `#exportPngButton`, `#reportErrorButton`.
  - `#status`, `#statusStaff` : indicateurs d'état.
- `#rsPlaybackControls` (injecté dynamiquement dans `#menu` par `realsheet.js` ligne 3020+) :
  - `#rsPlaybackPlay` (bouton lecture/arrêt) et `#rsPlaybackStatus`.

## 2. Navigation latérale (`#sideNav`)
Pages internes (`.nav-page`) :
- `#navTunes` : liste des morceaux (`#tuneSearch`, `#tbFilter`, `#nrOfTunes`, `#tuneList`, `#plusbutton`).
- `#navManageTunes` : gestion des tunebooks (`.tuneBookList`, `#plus2`, `#toggleAdvanced`, `#manageAdvanced`, `#downloadURL`, `#importListWeb`, `#fileInput`).
- `#navBackup` : sauvegarde/restauration (`#saveBackup`, `#restoreBackup`).
- `#navAbout` : à propos, liste des titres (`#createTitleList`), mise à jour (`#systemUpdateButton`), reset (`#resetButton`), infos système (`#showSysInfo`, `#sysInfo`).
- `#navMain` : menu principal (`#menuTunes`, `#menuManageTunebooks`, `#menuUpdateTunebooks`, `#menuBackup`, `#menuAbout`, `#menuInstall`, `#realsheetVersion`).

## 3. Zone partition et calques (`.settings-layer`)
- `#paperframe` > `#notes` + `#paper` : conteneur de la partition SVG rendue par `abcjs`.
- `#warnings`, `#spaceBelowSheet`, `#cover`, `#image-container`, `#spinnerOverlay`.
- Calques modaux : `#info`, `#abc` (`#ABCCode`), `#editor` (`#abctext`), `#audio`, `#installScreen`.

## 4. Variables globales et `localStorage` connus
Variables `window` exposées par les patchs :
- `window.rsApplyAllKeyAccidentals(abc)` : applique les altérations à la clé si `localStorage.getItem('rsAllKeyAccidentals') === '1'`.
- `window.rsFlattenNestedTuplets(text)` : aplatit les nuplets imbriqués ABC.
- `window.__rsCurrentVisual` : objet `tuneObject` retourné par `ABCJS.renderAbc` (`m[0]`).
- `window.__rsCurrentAbc` : chaîne ABC finale envoyée à `ABCJS.renderAbc`.
- `window.__rsPlaybackSynth`, `window.__rsPlaybackTiming`, `window.__rsPlaybackEndTimer` : instances actives du lecteur audio.
- `window.__rsAuto`, `window.__rsAutoFollow()` : état et fonction de défilement automatique pendant la lecture.
- `window.__rsLastRenderW` : dernière largeur d'écran ayant déclenché un rendu (protection contre le clavier virtuel mobile).
- `window.__RS_FILES__` : registre des fichiers `.json` injectés en mode `file://` par les sidecars `.json.js`.

Clés `localStorage` observées :
- `RealSheetTb` : catalogue des tunebooks importés (JSON).
- `rsAllKeyAccidentals` : `'1'` ou `'0'` (option `All #/b`).
- `RealSheetLastInstrument`, `RealSheetLastTitleNum`, `RealSheetLastTitleName`, `favList`, `RealSheetMsg` (et autres clés gérées par le cœur `realsheet.js`).

## 5. Ressources disponibles mais non câblées (v2.6.17)
- `app/img/up.png` et `app/img/down.png` : icônes présentes dans `app/img/` (ajoutées en 2.6.17), prêtes à être intégrées (ex. transposition rapide, navigation haut/bas ou défilement), penser à les ajouter à `PRECACHE_URLS` si utilisées.
- `app/playback.js` (`window.RealSheetPlayback`) : classe autonome non instanciée actuellement ; à supprimer ou unifier si une refonte audio est décidée.
