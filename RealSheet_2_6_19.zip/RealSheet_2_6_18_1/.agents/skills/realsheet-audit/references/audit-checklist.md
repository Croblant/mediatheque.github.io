# Grille d'audit manuel — RealSheet

Utiliser cette checklist en complément de `scripts/audit-project.mjs` lors d'un audit complet ou avant mise en ligne (ex. `realsheettest.fwh.is`).

## 1. Architecture, PWA & double mode d'exécution
- [ ] **Mode `http(s)://`** (`node serve.mjs 8000` -> `http://localhost:8000/app/realsheet.html`) :
  - Aucune erreur console au chargement.
  - Service Worker enregistré sous le scope `/app/` et installation complète sans 404 dans `PRECACHE_URLS`.
  - Mode hors ligne fonctionnel après premier chargement (DevTools -> Network -> Offline).
  - Relais `getkey.php` opérationnel (local via `serve.mjs`/`api/getkey.php` ou fallback `filemode.js` vers `realsheet.net`).
- [ ] **Mode `file://`** (ouverture directe de `RealSheet.html` ou `app/realsheet.html`) :
  - `lang.json.js` et `forum/forum.json.js` chargés via `filemode.js` sans erreur CORS bloquante.
  - Import de fichiers `.abc` / `.abct` locaux fonctionnel via *Edit Tunebooks > Advanced options > Select Tunebook File*.
- [ ] **Poids & déploiement** :
  - Vérifier s'il convient d'exclure `app/lib/github/` et `app/lib/lib initiale/` du package de production.

## 2. Rendu musical ABC & Transposition
- [ ] Transposition chromatique (`#steps`) et par instrument (`#steps2` : C, B♭, E♭, F, G, Bass -1/-2).
- [ ] Option **All #/b** (`#displayAllSharp` / `rsAllKeyAccidentals`) : affichage des altérations de l'armure devant chaque note, libellé basculant entre `All #/b` et `Normal #/b` sans fond bleu persistant.
- [ ] Affichage/masquage des paroles (`#displayHideLyrics`), taille des accords (`#displayLargeChords`), taille des portées (`Standard`, `Smaller`, `Smallest`).
- [ ] Nuplets imbriqués (`(17:8:35 ... (3EFG`) : rendu et durée audio corrects (`rsFlattenNestedTuplets` + `lib/abc.js`).
- [ ] Notes d'ornement (`gracenotes` / `acciaccatura`) : durée audio réaliste et note principale non tronquée à zéro.
- [ ] Annotations de reprise (`D.C.`, `D.S.`, `Fine`, `Coda`) marquées `.abcjs-repeat`.

## 3. Lecteur audio & Suivi visuel
- [ ] Bouton `#rsPlaybackPlay` présent dans `#menu`, basculant Lecture (`▶`) / Arrêt (`■`).
- [ ] Tempo par défaut (`120` BPM) injecté sans s'afficher visuellement si `Q:` est absent (`.rs-hide-tempo`).
- [ ] Surlignage des notes jouées (`.abcjs-highlight`) et défilement automatique (`__rsAutoFollow`) sans conflit avec le scroll manuel de l'utilisateur.
- [ ] Rotation d'écran / redimensionnement : en lecture, le synthé continue et `TimingCallbacks` se rattache aux nouveaux SVG ; sur mobile, l'ouverture du clavier virtuel ne déclenche pas de redessin intempestif (`__rsLastRenderW`).

## 4. Export, Impression & Stockage local
- [ ] `Print/PDF` (`@media print`) tient sur une seule page sans coupure ni débordement (`--sheet-hw`, `--notes-h`).
- [ ] Export PDF (`jspdf`) et PNG (`dom-to-image` + `UPNG`).
- [ ] Sauvegarde / Restauration (`#saveBackup`, `#restoreBackup`) et Notes personnelles (`#notesButton`).

## 5. Sécurité & Catalogue Forum
- [ ] Protection anti-SSRF intacte dans `serve.mjs`, `serve.py` et `api/proxy.php` (refus des IP privées/loopback/link-local, schémas http/https uniquement, plafond 5 Mo).
- [ ] Rendu sécurisé des entrées de `forum.json` via `escapeHtml()` dans `forum/forum.js`.
- [ ] Disponibilité et réponse CORS des URL externes listées dans `forum/forum.json`.
